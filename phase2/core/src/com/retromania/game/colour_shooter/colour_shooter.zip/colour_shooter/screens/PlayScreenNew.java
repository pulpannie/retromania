package com.retromania.game.colour_shooter.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.retromania.game.RetroMania;
import com.retromania.game.colour_shooter.individuals.Background;
import com.retromania.game.colour_shooter.individuals.Bullet;
import com.retromania.game.colour_shooter.individuals.Header;
import com.retromania.game.colour_shooter.individuals.Square;
import com.retromania.game.colour_shooter.individuals.Tank;
import com.retromania.game.colour_shooter.presenters.PlayScreenPresenter;
import com.retromania.game.colour_shooter.presenters.Presenter;
import com.retromania.game.colour_shooter.utils.ColourShooterListener;
import com.retromania.game.shared_abstractions.Renderable;
import com.retromania.game.shared_abstractions.RetroManiaGame;
import com.retromania.game.shared_abstractions.RetroManiaModel;
import com.retromania.game.shared_abstractions.RetroManiaScreen;
import com.retromania.game.tic_tac_toe.presenters.PlayPresenter;
import com.retromania.game.colour_shooter.ColourShooterStarter;

import java.util.Locale;

public class PlayScreenNew extends RetroManiaScreen {

    private PlayScreenPresenter presenter;
    private Viewport viewport;
    private Stage stage;
    private OrthographicCamera gameCam;
    private float gameWidth, gameHeight;
    private Square square;
    private float bullet_starting_pos;
    private boolean bullet_in_motion = false;
    private World world;
    private ColourShooterStarter mainScreen;
    private Box2DDebugRenderer b2ddr;
    private Integer worldTimer;
    private float timeCount;
    private String colour;
    private int score;
    private Label scoreTracker;
    private Label colourTracker;
    private Label timeTracker;
    private Table table;
    private Viewport headerViewport;
    private Stage stageHeader;

    public PlayScreenNew(ColourShooterStarter mainScreen) {
        this.mainScreen = mainScreen;
        setUpStage();
        Gdx.input.setInputProcessor(stage);

        presenter = new PlayScreenPresenter(mainScreen, gameWidth, gameHeight);
    }

    private void setUpStage() {
        this.gameWidth = Gdx.graphics.getHeight();
        this.gameHeight = Gdx.graphics.getWidth();
        this.gameCam = new OrthographicCamera();
        this.viewport = new StretchViewport(gameWidth, gameHeight,gameCam);
        this.viewport.setWorldSize(gameWidth, gameHeight);
        this.stage = new Stage(viewport, RetroMania.getRetroManiaInstance().sb);
    }

    @Override
    public void show() {
        stage.addActor(presenter.setUpBackground());
        stage.addActor(presenter.getTank());
        setupHeader();
        presenter.makeSquare();
    }

    public void setupHeader() {
        headerViewport = new FitViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), new OrthographicCamera());
        table = new Table();
        table.top();
        table.setFillParent(true);
        stageHeader = new Stage(headerViewport, RetroMania.getRetroManiaInstance().sb);
        Integer worldTimer = 30;
        timeCount = 0;
        score = 0;

        Label scoreText = new Label(String.format(Locale.US, "SCORE"), new Label.LabelStyle(new BitmapFont(), Color.BLACK));
        Label colourText = new Label(String.format(Locale.US,"COLOUR"), new Label.LabelStyle(new BitmapFont(), Color.BLACK));
        Label timeText = new Label(String.format(Locale.US,"TIME"), new Label.LabelStyle(new BitmapFont(), Color.BLACK));

        scoreTracker = new Label(String.format(Locale.US,"%03d", score), new Label.LabelStyle(new BitmapFont(), Color.BLACK));
        colourTracker = new Label(presenter.getColourText(), new Label.LabelStyle(new BitmapFont(), presenter.getColorObject()));
        timeTracker = new Label(String.format(Locale.US,"%02d", worldTimer), new Label.LabelStyle(new BitmapFont(), Color.BLACK));


        table.add(scoreText).expandX().padTop(10);
        table.add(colourText).expandX().padTop(10);
        table.add(timeText).expandX().padTop(10);
        table.row();
        table.add(scoreTracker).expandX();
        table.add(colourTracker).expandX();
        table.add(timeTracker).expandX();

        Actor[] actors = {scoreText, colourText, timeText,
                scoreTracker, colourTracker, timeTracker, table};
        for (Actor act: actors) {
            stageHeader.addActor(act);
        }

    }

    public void update(float dt) {
        super.update();
        presenter.updateTime(dt);
        presenter.checkCollided();
        if (presenter.getCollided()) {
            updateHeaderColour();
            updateHeaderScore();
            presenter.setCollision(false);
        }
        updateHeaderTime();
        presenter.getSquare().rotateSquare();
    }

    public void updateHeaderColour() {
        colourTracker.setText(presenter.getColourText());
        colourTracker.setStyle(new Label.LabelStyle(new BitmapFont(),
                presenter.getColorObject()));
    }

    public void updateHeaderScore() {
        scoreTracker.setText(String.format(Locale.US, "%03d",
                presenter.getScore()));
    }

    private void updateHeaderTime() {
        int time = presenter.getTime();
        timeTracker.setText(String.format(Locale.US, "%02d", time));
        if (time <= 10) {
            timeTracker.setStyle(new Label.LabelStyle(new BitmapFont(), Color.RED));
        }
    }

    @Override
    public void handleInput() {
        if (Gdx.input.isTouched()) {
            presenter.justTouched();
        }
    }

    @Override
    public void render(final float delta) {
        update(delta);

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.draw();
        stageHeader.draw();

        RetroMania.getRetroManiaInstance().sb.begin();
        RetroMania.getRetroManiaInstance().sb.setProjectionMatrix(viewport.getCamera().combined);
        presenter.getSquare().draw(RetroMania.getRetroManiaInstance().sb);

        if (presenter.getBullet() != null) {
            presenter.getBullet().draw(RetroMania.getRetroManiaInstance().sb);

        }
        RetroMania.getRetroManiaInstance().sb.end();

        //b2ddr.render(world, viewport.getCamera().combined);
    }

    @Override
    public void resize(int width, int height) {

    }
}
