package com.retromania.game.colour_shooter.screens;

public class SquareRenderer {

}
