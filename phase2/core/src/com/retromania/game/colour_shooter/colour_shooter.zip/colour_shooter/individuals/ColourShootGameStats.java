package com.retromania.game.colour_shooter.individuals;

public class ColourShootGameStats {
}
