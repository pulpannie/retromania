package com.retromania.game.colour_shooter.presenters;

public class InstructionsScreen {
}
