package com.retromania.game.colour_shooter.utils;

public class Constants {
    public static final short BIT_SQUARE = 1;
    public static final short BIT_RED = 2;
    public static final short BIT_GREEN = 4;
    public static final short BIT_BLUE = 8;
    public static final short BIT_YELLOW = 16;
    public static final short BIT_BULLET = 32;
    public static final short PPM = 32;
}
